# Weekly Put Scanner

This package includes the Flask app and its standalone HTML client. The app serves its own page at `/`; for a separately hosted `index.html`, set `window.API_URL` in `config.js` to the Flask API origin.

## Required deployment settings

- `APP_PASSWORD`: a strong, unique password used for order placement and sending email/SMS results.
- `ALPACA_API_KEY` and `ALPACA_SECRET_KEY`: Alpaca credentials. Start with paper credentials.
- `LIVE_TRADING=false`: keep live order placement disabled until the paper flow and account settings are checked.

Optional CORS setting: `ALLOWED_ORIGINS` to restrict browser requests to one or more comma-separated frontend origins (for example `https://frontend-option-trading-nu.vercel.app`). `FRONTEND_ORIGIN` remains a backward-compatible single-origin alias. If neither is set, browser access defaults to `*`.

Optional AI settings: `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, or `OMNIROUTE_BASE_URL` with `OMNIROUTE_API_KEY` and `OMNIROUTE_MODEL` as needed.

The in-app guide uses the first configured AI provider to answer questions about navigating the scanner. It does not recommend trades or place orders.

For a separately hosted frontend, `config.js` sets its API URL to the Flask backend. The Flask-served page uses same-origin routes automatically.

Optional email settings: `EMAIL_FROM`, `EMAIL_APP_PASSWORD` (Gmail app password), and `ALERT_EMAIL` (comma-separated approved recipients, up to five).

Optional SMS settings: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, and `ALERT_PHONE` (comma-separated approved recipients in E.164 format, up to five).

Set `MAX_CONTRACTS` from 1 to 100 and `MAX_COLLATERAL_PCT` above 0 and at most 1. Invalid values stop startup.

## Notes

- Email and SMS endpoints require the same bearer password as the order endpoint. They send only to recipients configured by the operator; recipients cannot be supplied in the request.
- Request throttles are in-process best-effort limits and trust one reverse proxy for client IP forwarding. Confirm that matches your host; multi-instance/serverless deployments should add a shared edge or Redis-backed limiter.
- The scanner uses Yahoo Finance data. Underlying prices are daily closes and option quotes may be delayed. Verify a current quote with the broker before placing an order; the live order route requires the confirmation flag.
- `broker.py` is retained from the source archive but is not wired into `app.py`; orders in this app use Alpaca.
- `all-features-fixed`, `all 4 feature`, and patch files from the source archive are omitted because they are unapplied patch material and should not be used as deployment instructions.
